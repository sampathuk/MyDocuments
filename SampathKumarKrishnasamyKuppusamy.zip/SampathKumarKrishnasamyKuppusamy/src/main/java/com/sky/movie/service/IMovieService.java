package com.sky.movie.service;

import com.sky.movie.exceptions.TechnicalFailureException;
import com.sky.movie.exceptions.TitleNotFoundException;

/**
*
* Interface for Movie Service 
*
* @author Sampath
* @version 16.00, 11 Mar 2016
* 
*/
public interface IMovieService {
	
	/**
    *
    * This method gets the parental control level for a movie id
    *
    * @param movieId  Movie id
    * @return parental control level of the movie
    * @throws TitleNotFoundException	Movie id not found 
    * @throws TechnicalFailureException Technical error

    * 
    */	
	String getParentalControlLevel(String movieId)
			throws TitleNotFoundException,
			TechnicalFailureException;
}
