package com.sky.movie.enums;

public enum ParentalControlLevelEnum {
	LU(0), LPG(1), L12(2), L15(3), L18(4);

	private int pcValue;

	private ParentalControlLevelEnum(int value) {
		this.pcValue = value;
	}

	public static ParentalControlLevelEnum getParentalControlLevel(String pcLevelValue) {
		for (ParentalControlLevelEnum pclEnum : ParentalControlLevelEnum.values()) {
			if (pcLevelValue.equals(pclEnum.name())) {
				return pclEnum;
			}
		}
		return null;
	}

	public static Boolean compareParentalControlLevel(ParentalControlLevelEnum customerPerference,
			ParentalControlLevelEnum actualPerference) {
		if (actualPerference.pcValue <= customerPerference.pcValue) {
			return true;
		} else {
			return false;
		}
	}

}
