package com.sky.movie.controller;

import org.springframework.aop.ThrowsAdvice;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sky.movie.enums.ParentalControlLevelEnum;
import com.sky.movie.exceptions.TechnicalFailureException;
import com.sky.movie.exceptions.TitleNotFoundException;
import com.sky.movie.service.IMovieService;
import com.sky.movie.service.impl.MovieService;

/**
*
* @author Sampath
* @version 16.00, 11 Mar 2016
* 
*/
@RestController
public class ParentalControlService {

	/**
    *
    * Controller to receive the request and determine whether the movie can be viewed by customer 
    *
    * @param customerPreference Customer parental preference
    * @param movieId Movie id
    * @return true customer can watch the movie
    * @return false customer can't watch the movie
    * @throws TitleNotFoundException	Movie id not found 
    * @throws TechnicalFailureException Technical error
    * 
    */
	@RequestMapping("/parentalcontrol")
	public Boolean getParentalControlLevel(
			@RequestParam(value = "customerPreference", defaultValue = "U") String customerPreference,
			@RequestParam(value = "movieId", defaultValue = "0") String movieId)
					throws TitleNotFoundException, TechnicalFailureException {

		IMovieService movieService = new MovieService();

		ParentalControlLevelEnum customerPreferenceLevel = null;

		if (customerPreference != null) {
			customerPreferenceLevel = ParentalControlLevelEnum.getParentalControlLevel("L".concat(customerPreference));
		}

		String parentalControlOfMovieString = movieService.getParentalControlLevel(movieId);

		if (parentalControlOfMovieString != null) {
			ParentalControlLevelEnum parentalControlOfMovie = ParentalControlLevelEnum
					.valueOf(parentalControlOfMovieString);

			// System.out.println("customerPreferenceLevel =" +
			// customerPreferenceLevel + "; parentalControlOfMovie =" +
			// parentalControlOfMovie);

			return ParentalControlLevelEnum.compareParentalControlLevel(customerPreferenceLevel,
					parentalControlOfMovie);
		}

		return false;
	}
}
