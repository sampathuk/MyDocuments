package com.sky.movie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
*
* @author Sampath
* @version 16.00, 11 Mar 2016
* 
*/
@SpringBootApplication
public class Application {

	/**
    *
    * Main class of Spring Boot application 
    *
    * @param args Default array of strings 
    * 
    */
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
