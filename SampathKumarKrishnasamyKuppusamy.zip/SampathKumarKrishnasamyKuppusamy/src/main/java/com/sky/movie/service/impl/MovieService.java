package com.sky.movie.service.impl;

import org.springframework.util.StringUtils;

import com.sky.movie.constants.IApplicationConstants;
import com.sky.movie.enums.ParentalControlLevelEnum;
import com.sky.movie.exceptions.TechnicalFailureException;
import com.sky.movie.exceptions.TitleNotFoundException;
import com.sky.movie.service.IMovieService;

/**
 *
 * @author Sampath
 * @version 16.00, 11 Mar 2016
 */
public class MovieService implements IMovieService, IApplicationConstants {

	/**
    *
    * This method gets the parental control level for a movie id
    *
    * @param movieId MovieId of the movie
    * @return parental control level of the movie
    * @throws TitleNotFoundException	Movie id not found 
    * @throws TechnicalFailureException Technical error
    * 
    */
	@SuppressWarnings("unused")
	@Override
	public String getParentalControlLevel(String movieId) throws TitleNotFoundException, TechnicalFailureException {

		if (movieId == null || movieId.equals("null") || StringUtils.isEmpty(movieId)) {
			throw new TechnicalFailureException(IApplicationConstants.TECH_ERROR_MESSAGE,
					IApplicationConstants.EXCEPTION_CODE_500, new Exception());
		} else if (movieId != null) {

			if (movieId.equals("0")) {
				throw new TitleNotFoundException(IApplicationConstants.MOVIE_NOT_FOUND_MESSAGE,
						IApplicationConstants.EXCEPTION_CODE_204, new Exception());
			} else if (movieId.equals("U")) {
				return ParentalControlLevelEnum.LU.name();
			} else if (movieId.equals("PG")) {
				return ParentalControlLevelEnum.LPG.name();
			} else if (movieId.equals("12")) {
				return ParentalControlLevelEnum.L12.name();
			} else if (movieId.equals("15")) {
				return ParentalControlLevelEnum.L15.name();
			} else if (movieId.equals("18")) {
				return ParentalControlLevelEnum.L18.name();
			} else {
				throw new TitleNotFoundException(IApplicationConstants.MOVIE_NOT_FOUND_MESSAGE,
						IApplicationConstants.EXCEPTION_CODE_204, new Exception());
			}

		}
		return null;
	}

}
