package com.sky.movie.constants;

/**
*
* Interface to maintain the application constants
*
* @author Sampath
* @version 16.00, 11 Mar 2016
* 
*/
public interface IApplicationConstants {

	String MOVIE_NOT_FOUND_MESSAGE = "The movie service could not find the given movie";
	
	String TECH_ERROR_MESSAGE = "System error: Customer cannot watch this movie";
	
	//Technical Exception 
	String EXCEPTION_CODE_500 = "500";
	
	//No movie found
	String EXCEPTION_CODE_204 = "204";

}
